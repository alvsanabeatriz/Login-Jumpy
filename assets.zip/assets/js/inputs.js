const inputList = [
  document.getElementById("input-1"),
  document.getElementById("input-2"),
  document.getElementById("input-3"),
  document.getElementById("input-4"),
  document.getElementById("input-5"),
];

const onChange = (event) => {
  let getIdOnInput = event.target.id.split("");
  if (event.target.value !== "") {
    document.querySelector(
      `.span-${getIdOnInput[getIdOnInput.length - 1]}`
    ).style.display = "none";
    
    event.target.style.marginBottom = "1.375rem";
  }
};

inputList.forEach((item, i, arr) => (arr[i].onchange = onChange));
