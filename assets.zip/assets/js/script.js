const form = document.getElementById("form-main")
let label, input, span;

infosForm.forEach((item, i) => {
    label = document.createElement("label")
    input = document.createElement("input")
    input.id = `input-${i+1}`
    span = document.createElement("span") 
    span.className = `span-${i+1}`
    label.innerHTML = item.label
    input.placeholder = item.placeholder
    form.appendChild(label)
    form.appendChild(input)
    form.appendChild(span)
})

const button = document.createElement("button")
button.type = "submit"
const textButton = document.createTextNode("Cadastrar")
button.appendChild(textButton)
form.appendChild(button)

// Débito técnico: condição de vitória e validação dos campos

const verify = () => inputList.forEach((item, i) => {
    let acm = 0;
    if (item.value === "") {
        item.style.marginBottom = 0
        document.querySelector(`.span-${i+1}`).style.display = "initial"
        document.querySelector(`.span-${i+1}`).style.marginBottom = "0.5rem"
        document.querySelector(`.span-${i+1}`).innerHTML = "*Campo Obrigatório*"
    } else {
        acm++
    }

    // if (acm === 5) {

    // }
})

const prevEvent = event => event.preventDefault()

button.addEventListener("click", prevEvent)

button.onclick = verify


