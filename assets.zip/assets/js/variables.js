const infosForm = [
    {
        label: "Nome Completo:",
        placeholder: "Nome completo"
    },
    {
        label: "Email:",
        placeholder: "Email@email.com",
        regex: /\S+@\S+\.\S+/
    },
    {
        label: "Telefone:",
        placeholder: "(00) 00000-0000",
        regex: /(?:(^\+\d{2})?)(?:([1-9]{2})|([0-9]{3})?)(\d{4,5})(\d{4})/
    },
    {
        label: "CPF:",
        placeholder: "000.000.000-00",
        regex: /([0-9]{2}[\.]?[0-9]{3}[\.]?[0-9]{3}[\/]?[0-9]{4}[-]?[0-9]{2})|([0-9]{3}[\.]?[0-9]{3}[\.]?[0-9]{3}[-]?[0-9]{2})/
    },
    {
        label: "Senha:",
        placeholder: "*******************"
    },
]

